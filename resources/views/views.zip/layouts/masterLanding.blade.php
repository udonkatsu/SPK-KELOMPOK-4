@include('layouts.headerLanding')
@yield('content')
@include('layouts.footerLanding')
